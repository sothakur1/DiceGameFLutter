import 'dart:async';
import 'dart:math';

class GameViewModel {
  int totalAmount = 100;
  int round = 1;
  double selectedNumber = 4;
  double betPercentage = 10;
  List<String> diceImages = ['Roll.png', 'Roll.png', 'Roll.png', 'Roll.png'];
  String sumDisplay = "-";

  void rollDice() {
    if (totalAmount <= 0) {
      return;
    }

    var newDiceValues = List.generate(4, (_) => Random().nextInt(6) + 1);
    diceImages = newDiceValues.map((val) => 'Dice$val.png').toList();
    sumDisplay =
        newDiceValues.reduce((sum, element) => sum + element).toString();
    calculateResult();
    round++;
  }

  void calculateResult() {
    int diceSum = diceImages
        .map((name) => int.parse(name.replaceAll(RegExp(r'[^\d]'), '')))
        .reduce((sum, element) => sum + element);
    int guessedSum = selectedNumber.toInt();
    int difference = (diceSum - guessedSum).abs();
    double multiplier = 0;

    if (difference == 0) {
      multiplier = 1.0;
    } else if (difference <= 5) {
      multiplier = 1.0 - (difference * 0.2);
    }

    int betAmount = (totalAmount * (betPercentage / 100)).round();
    int winnings = (betAmount * multiplier).round();

    if (multiplier == 0) {
      totalAmount -= betAmount;
    } else {
      totalAmount += winnings;
    }

    if (totalAmount <= 0) {
      Future.delayed(Duration.zero, () => showLostMessage());
    }
  }

  void resetGame() {
    totalAmount = 100;
    round = 1;
    selectedNumber = 4;
    betPercentage = 10;
    diceImages = ['Roll.png', 'Roll.png', 'Roll.png', 'Roll.png'];
    sumDisplay = "__";
  }

  void showLostMessage() {}
}
