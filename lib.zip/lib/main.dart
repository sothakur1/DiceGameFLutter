import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import 'view/rules_screen.dart';
import 'view/about_screen.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dice Game',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
        primaryColor: Colors.green[400],
      ),
      home: GameScreen(),
    );
  }
}

class GameScreen extends StatefulWidget {
  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  int totalAmount = 100;
  int round = 1;
  double selectedNumber = 4;
  double betPercentage = 10;
  List<String> diceImages = ['Roll.png', 'Roll.png', 'Roll.png', 'Roll.png'];
  String sumDisplay = "-";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      appBar: AppBar(
        title: Text('Dice Game'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0),
        child: SingleChildScrollView(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Text('Round: $round',
                    style: Theme.of(context).textTheme.headline6),
                SizedBox(height: 20),
                Text('Total Amount: $totalAmount',
                    style: Theme.of(context).textTheme.headline6),
                SizedBox(height: 20),
                Text('Guess a number between 4 and 24',
                    style: Theme.of(context).textTheme.subtitle1),
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    activeTrackColor: Colors.yellow[700],
                    inactiveTrackColor: Colors.yellow[100],
                    trackShape: RoundedRectSliderTrackShape(),
                    trackHeight: 4.0,
                    thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12.0),
                    thumbColor: Colors.yellowAccent,
                    overlayColor: Colors.yellow.withAlpha(32),
                    overlayShape: RoundSliderOverlayShape(overlayRadius: 28.0),
                    tickMarkShape: RoundSliderTickMarkShape(),
                    activeTickMarkColor: Colors.yellow[700],
                    inactiveTickMarkColor: Colors.yellow[100],
                    valueIndicatorShape: PaddleSliderValueIndicatorShape(),
                    valueIndicatorColor: Colors.yellowAccent,
                    valueIndicatorTextStyle: TextStyle(
                      color: Colors.black,
                    ),
                  ),
                  child: Slider(
                    min: 4,
                    max: 24,
                    divisions: 20,
                    label: selectedNumber.round().toString(),
                    value: selectedNumber,
                    onChanged: (value) {
                      setState(() {
                        selectedNumber = value;
                      });
                    },
                  ),
                ),
                SizedBox(height: 20),
                Text('Choose the bet amount',
                    style: Theme.of(context).textTheme.subtitle1),
                Slider(
                  min: 10,
                  max: 100,
                  divisions: 9,
                  label: '$betPercentage%',
                  value: betPercentage,
                  onChanged: (value) {
                    setState(() {
                      betPercentage = value;
                    });
                  },
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: rollDice,
                  child: Text('Roll Dice'),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: resetGame,
                  child: Text('Reset Game'),
                ),
                SizedBox(height: 20),
                Text('Dice Sum: $sumDisplay',
                    style: Theme.of(context).textTheme.headline6),
                SizedBox(height: 20),
                Wrap(
                  spacing: 8.0,
                  children: diceImages
                      .map((imageName) => Image.asset('assets/$imageName',
                          width: 50, height: 50))
                      .toList(),
                ),
                SizedBox(height: 40),
                ElevatedButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RulesScreen()),
                  ),
                  child: Text('Rules'),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AboutScreen()),
                  ),
                  child: Text('About'),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void rollDice() {
    if (totalAmount <= 0) {
      return;
    }

    var newDiceValues = List.generate(4, (_) => Random().nextInt(6) + 1);
    setState(() {
      diceImages = newDiceValues.map((val) => 'Dice$val.png').toList();
      sumDisplay =
          newDiceValues.reduce((sum, element) => sum + element).toString();
      calculateResult();
      round++;
    });
  }

  void calculateResult() {
    int diceSum = diceImages
        .map((name) => int.parse(name.replaceAll(RegExp(r'[^\d]'), '')))
        .reduce((sum, element) => sum + element);
    int guessedSum = selectedNumber.toInt();
    int difference = (diceSum - guessedSum).abs();
    double multiplier = 0;

    if (difference == 0) {
      multiplier = 1.0;
    } else if (difference <= 5) {
      multiplier = 1.0 - (difference * 0.2);
    }

    int betAmount = (totalAmount * (betPercentage / 100)).round();
    int winnings = (betAmount * multiplier).round();

    if (multiplier == 0) {
      totalAmount -= betAmount;
    } else {
      totalAmount += winnings;
    }

    if (totalAmount <= 0) {
      Future.delayed(Duration.zero, () => showLostMessage());
    }
  }

  void resetGame() {
    setState(() {
      totalAmount = 100;
      round = 1;
      selectedNumber = 4;
      betPercentage = 10;
      diceImages = ['Roll.png', 'Roll.png', 'Roll.png', 'Roll.png'];
      sumDisplay = "__";
    });
  }

  void showLostMessage() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Game Over"),
            content: Text("Lost all the amount :( Please play again."),
            actions: <Widget>[
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        }).then((_) => resetGame());
  }
}
