import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'rules_screen.dart';
import 'about_screen.dart';
import '../model/game_model.dart';

class GameView extends StatefulWidget {
  @override
  _GameViewState createState() => _GameViewState();
}

class _GameViewState extends State<GameView> {
  final _viewModel = GameViewModel();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      appBar: AppBar(
        title: Text('Dice Game'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0),
        child: SingleChildScrollView(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Text('Round: ${_viewModel.round}',
                    style: Theme.of(context).textTheme.headline6),
                SizedBox(height: 20),
                Text('Total Amount: ${_viewModel.totalAmount}',
                    style: Theme.of(context).textTheme.headline6),
                SizedBox(height: 20),
                Text('Guess a number between 4 and 24',
                    style: Theme.of(context).textTheme.subtitle1),
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    activeTrackColor: Colors.yellow[700],
                    inactiveTrackColor: Colors.yellow[100],
                    trackShape: RoundedRectSliderTrackShape(),
                    trackHeight: 4.0,
                    thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12.0),
                    thumbColor: Colors.yellowAccent,
                    overlayColor: Colors.yellow.withAlpha(32),
                    overlayShape: RoundSliderOverlayShape(overlayRadius: 28.0),
                    tickMarkShape: RoundSliderTickMarkShape(),
                    activeTickMarkColor: Colors.yellow[700],
                    inactiveTickMarkColor: Colors.yellow[100],
                    valueIndicatorShape: PaddleSliderValueIndicatorShape(),
                    valueIndicatorColor: Colors.yellowAccent,
                    valueIndicatorTextStyle: TextStyle(
                      color: Colors.black,
                    ),
                  ),
                  child: Slider(
                    min: 4,
                    max: 24,
                    divisions: 20,
                    label: _viewModel.selectedNumber.round().toString(),
                    value: _viewModel.selectedNumber,
                    onChanged: (value) {
                      setState(() {
                        _viewModel.selectedNumber = value;
                      });
                    },
                  ),
                ),
                SizedBox(height: 20),
                Text('Choose the bet amount',
                    style: Theme.of(context).textTheme.subtitle1),
                Slider(
                  min: 10,
                  max: 100,
                  divisions: 9,
                  label: '${_viewModel.betPercentage}%',
                  value: _viewModel.betPercentage,
                  onChanged: (value) {
                    setState(() {
                      _viewModel.betPercentage = value;
                    });
                  },
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _viewModel.rollDice,
                  child: Text('Roll Dice'),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _viewModel.resetGame,
                  child: Text('Reset Game'),
                ),
                SizedBox(height: 20),
                Text('Dice Sum: ${_viewModel.sumDisplay}',
                    style: Theme.of(context).textTheme.headline6),
                SizedBox(height: 20),
                Wrap(
                  spacing: 8.0,
                  children: _viewModel.diceImages
                      .map((imageName) => Image.asset('assets/$imageName',
                          width: 50, height: 50))
                      .toList(),
                ),
                SizedBox(height: 40),
                ElevatedButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RulesScreen()),
                  ),
                  child: Text('Rules'),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AboutScreen()),
                  ),
                  child: Text('About'),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
