import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple[900],
      appBar: AppBar(
        title: Text("About", style: TextStyle(color: Colors.orangeAccent)),
        backgroundColor: Colors.deepPurple[700],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.orangeAccent,
                  width: 4,
                ),
                shape: BoxShape.circle,
              ),
              child: CircleAvatar(
                radius: 100,
                backgroundImage: AssetImage('assets/Rutvij.jpg'),
              ),
            ),
            SizedBox(height: 20),
            Text(
              "As a dedicated software engineer with a strong background in full-stack development, I have honed my skills in Node.js and React.js, as well as WordPress for content-driven websites. I am eager to leverage my expertise to drive innovation and success in full-time SDE positions.",
              style: TextStyle(
                color: Colors.orangeAccent,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Tahoma',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                _showMessagePopup(context);
              },
              child: Text('Show Message'),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pop(context);
        },
        child: Icon(Icons.arrow_back),
        backgroundColor: Colors.orangeAccent,
      ),
    );
  }

  void _showMessagePopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Special Message",
              style: TextStyle(
                  fontWeight: FontWeight.bold, color: Colors.deepPurple)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Hi, I am Rutvij",
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.deepPurple),
              ),
              SizedBox(height: 8),
              Text("Thanks for checking out this special message!",
                  style: TextStyle(color: Colors.deepPurple)),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('OK', style: TextStyle(color: Colors.deepPurple)),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
