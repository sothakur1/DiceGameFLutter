import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class RulesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepOrange[900],
      appBar: AppBar(
        title: Text("Game Rules",
            style: TextStyle(color: Colors.lightGreenAccent)),
        backgroundColor: Colors.deepOrange[700],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: ListView(
          children: const <Widget>[
            Text("1) The game starts with a total amount of 100 points.",
                style: TextStyle(
                    color: Colors.lightGreenAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)), // Customized text style
            Text(
                "2) Players guess a total sum of four dice, choosing a number between 4 and 24.",
                style: TextStyle(
                    color: Colors.lightGreenAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)), // Customized text style
            Text(
                "3) Players then select a percentage of their total points to bet on their guess.",
                style: TextStyle(
                    color: Colors.lightGreenAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)), // Customized text style
            Text(
                "4) The betting amount ranges from 10% to 100% of the player's current total points.",
                style: TextStyle(
                    color: Colors.lightGreenAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)), // Customized text style
            Text(
                "5) Press 'Roll Dice' to roll the four dice and calculate their total sum.",
                style: TextStyle(
                    color: Colors.lightGreenAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)), // Customized text style
            Text(
                "6) If the guessed sum matches the actual dice sum, players win 100% of the bet amount.",
                style: TextStyle(
                    color: Colors.lightGreenAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)), // Customized text style
            Text(
                "7) Winning percentages decrease as the difference between the guessed sum and the actual sum increases, with specific tiers for +1/-1, +2/-2, etc., up to +5/-5 differences.",
                style: TextStyle(
                    color: Colors.lightGreenAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)), // Customized text style
            Text(
                "8) A difference more than +5 or -5 results in losing the bet amount.",
                style: TextStyle(
                    color: Colors.lightGreenAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)), // Customized text style
            Text(
                "9) The game continues with updated total points until the player decides to reset or loses all points.",
                style: TextStyle(
                    color: Colors.lightGreenAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)), // Customized text style
            Text(
                "10) Players can reset the game at any time to start over with 100 points.",
                style: TextStyle(
                    color: Colors.lightGreenAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)), // Customized text style
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pop(context);
        },
        backgroundColor: Colors.lightGreenAccent,
        child: Icon(Icons.arrow_back, color: Colors.deepOrange[900]),
      ),
    );
  }
}
